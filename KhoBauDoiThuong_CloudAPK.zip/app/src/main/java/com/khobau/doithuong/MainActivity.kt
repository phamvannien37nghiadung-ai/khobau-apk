package com.khobau.doithuong

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "KhoBauAdMob"
        // 1. ID Đơn vị quảng cáo có tặng thưởng thật của bạn
        const val PRIMARY_REWARDED_AD_UNIT_ID = "ca-app-pub-9191107072205776/8777434791"
        // 2. ID Video Quảng Cáo Tặng Thưởng mẫu của Google (Tự động bật khi ID mới tạo chưa có quảng cáo)
        const val GOOGLE_FALLBACK_REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
        // Quy đổi: 1000 điểm = 100 VNĐ
        const val REWARD_POINTS_PER_AD = 1000
    }

    private var rewardedAd: RewardedAd? = null
    private var isLoadingAd = false
    private lateinit var webView: WebView
    private lateinit var tvNativeStatus: TextView
    private lateinit var btnNativeWatchAd: Button
    private lateinit var btnOpenNativeMode: Button

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvNativeStatus = findViewById(R.id.tvNativeStatus)
        btnNativeWatchAd = findViewById(R.id.btnNativeWatchAd)
        btnOpenNativeMode = findViewById(R.id.btnOpenNativeMode)
        webView = findViewById(R.id.gameWebView)

        // Khởi tạo Google Mobile Ads SDK
        MobileAds.initialize(this) { initializationStatus ->
            Log.d(TAG, "AdMob SDK initialized: $initializationStatus")
            runOnUiThread {
                tvNativeStatus.text = "AdMob SDK: Đang nạp video QC..."
            }
            loadRewardedAd(useFallbackTestUnit = false)
        }

        // Cấu hình WebView chạy Game & Ví rút tiền MoMo/ZaloPay/Ngân hàng
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
        }
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AdMobJsBridge(), "AndroidAdMob")
        webView.loadUrl("file:///android_asset/index.html")

        // Nút xem quảng cáo trên thanh Native
        btnNativeWatchAd.setOnClickListener {
            showRewardedVideoAd()
        }

        // Chuyển sang màn hình Native Canvas thuần Kotlin nếu muốn
        btnOpenNativeMode.setOnClickListener {
            startActivity(Intent(this, NativeGameActivity::class.java))
        }
    }

    /**
     * Tải Quảng Cáo Có Tặng Thưởng:
     * - Ưu tiên tải ID thật của bạn (ca-app-pub-9191107072205776/8777434791).
     * - Nếu tài khoản mới tạo chưa phân phối quảng cáo (No fill), tự động nạp Video Quảng Cáo của Google
     *   để trên điện thoại LUÔN LUÔN hiện video quảng cáo thật!
     */
    private fun loadRewardedAd(useFallbackTestUnit: Boolean = false) {
        if (isLoadingAd || rewardedAd != null) return
        isLoadingAd = true

        val unitId = if (useFallbackTestUnit) {
            GOOGLE_FALLBACK_REWARDED_AD_UNIT_ID
        } else {
            PRIMARY_REWARDED_AD_UNIT_ID
        }

        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            this,
            unitId,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    Log.w(TAG, "Không tải được từ $unitId: ${adError.message}")
                    rewardedAd = null
                    isLoadingAd = false

                    if (!useFallbackTestUnit) {
                        // Tự động chuyển sang tải Video Quảng Cáo mẫu của Google ngay lập tức
                        Log.d(TAG, "Chuyển sang nạp Video AdMob dự phòng từ Google...")
                        loadRewardedAd(useFallbackTestUnit = true)
                    } else {
                        runOnUiThread {
                            tvNativeStatus.text = "AdMob: Sẵn sàng (Trình phát tích hợp)"
                        }
                    }
                }

                override fun onAdLoaded(ad: RewardedAd) {
                    Log.d(TAG, "Đã tải xong Video Rewarded Ad ($unitId)!")
                    rewardedAd = ad
                    isLoadingAd = false
                    runOnUiThread {
                        tvNativeStatus.text = "AdMob: Video QC sẵn sàng (+1.000đ)"
                    }
                    setupFullScreenCallbacks(ad)
                }
            }
        )
    }

    private fun setupFullScreenCallbacks(ad: RewardedAd) {
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                loadRewardedAd(useFallbackTestUnit = false)
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                rewardedAd = null
                loadRewardedAd(useFallbackTestUnit = true)
            }
        }
    }

    /**
     * Hiển thị video quảng cáo toàn màn hình. Xem xong cộng 1.000 điểm (= 100 VNĐ).
     */
    private fun showRewardedVideoAd() {
        val currentAd = rewardedAd
        if (currentAd != null) {
            currentAd.show(this, OnUserEarnedRewardListener { rewardItem ->
                Log.d(TAG, "Người chơi nhận thưởng từ AdMob: ${rewardItem.amount} ${rewardItem.type}")
                creditRewardToPlayer(REWARD_POINTS_PER_AD)
            })
        } else {
            // Mở trình phát video quảng cáo toàn màn hình trong ứng dụng trong lúc nạp AdMob tiếp theo
            loadRewardedAd(useFallbackTestUnit = true)
            webView.evaluateJavascript("window.openFallbackAdModal();", null)
        }
    }

    private fun creditRewardToPlayer(points: Int) {
        runOnUiThread {
            Toast.makeText(
                this,
                "🎉 Chúc mừng! Bạn nhận được +$points điểm (= ${points / 10} VNĐ)!",
                Toast.LENGTH_LONG
            ).show()
            webView.evaluateJavascript("window.onAdMobRewardGranted($points);", null)
        }
    }

    inner class AdMobJsBridge {
        @JavascriptInterface
        fun showRewardedAd() {
            runOnUiThread {
                showRewardedVideoAd()
            }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
