package com.khobau.doithuong

import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlin.random.Random

class NativeGameActivity : AppCompatActivity() {

    private var points: Int = 2000 // 1000 điểm = 100 VNĐ
    private var rewardedAd: RewardedAd? = null
    private lateinit var tvBalance: TextView
    private lateinit var gameView: TreasureCanvasView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("kho_bau_native_prefs", Context.MODE_PRIVATE)
        points = prefs.getInt("points", 2000)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F172A"))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(32, 28, 32, 28)
            setBackgroundColor(Color.parseColor("#1E293B"))
            gravity = Gravity.CENTER_VERTICAL
        }

        tvBalance = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.parseColor("#FBBF24"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        header.addView(tvBalance)

        val btnBack = Button(this).apply {
            text = "Đóng"
            setOnClickListener { finish() }
        }
        header.addView(btnBack)
        root.addView(header)

        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(24, 16, 24, 16)
        }

        val btnWatchAd = Button(this).apply {
            text = "📺 Xem QC (+1.000 Điểm = 100đ)"
            setBackgroundColor(Color.parseColor("#F59E0B"))
            setTextColor(Color.parseColor("#0F172A"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = 12
            }
            setOnClickListener { showAdOrReward() }
        }

        val btnWithdraw = Button(this).apply {
            text = "🏦 Rút Tiền"
            setBackgroundColor(Color.parseColor("#10B981"))
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            setOnClickListener { openWithdrawDialog() }
        }

        actionRow.addView(btnWatchAd)
        actionRow.addView(btnWithdraw)
        root.addView(actionRow)

        gameView = TreasureCanvasView(this) { earnedPts ->
            addPoints(earnedPts)
        }
        root.addView(
            gameView,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        setContentView(root)
        updateBalanceText()
        loadNativeRewardedAd(useFallback = false)
    }

    private fun addPoints(delta: Int) {
        points += delta
        getSharedPreferences("kho_bau_native_prefs", Context.MODE_PRIVATE)
            .edit()
            .putInt("points", points)
            .apply()
        updateBalanceText()
    }

    private fun updateBalanceText() {
        val vnd = points / 10
        tvBalance.text = "⭐ $points điểm (= ${vnd}đ)  |  1.000đ = 100 VNĐ"
    }

    private fun loadNativeRewardedAd(useFallback: Boolean) {
        val unitId = if (useFallback) {
            MainActivity.GOOGLE_FALLBACK_REWARDED_AD_UNIT_ID
        } else {
            MainActivity.PRIMARY_REWARDED_AD_UNIT_ID
        }
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            this,
            unitId,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    if (!useFallback) {
                        loadNativeRewardedAd(useFallback = true)
                    }
                }
            }
        )
    }

    private fun showAdOrReward() {
        val ad = rewardedAd
        if (ad != null) {
            ad.show(this, OnUserEarnedRewardListener {
                addPoints(1000)
                Toast.makeText(this, "🎉 Đã nhận +1.000 điểm (= 100 VNĐ) từ AdMob!", Toast.LENGTH_LONG).show()
                rewardedAd = null
                loadNativeRewardedAd(useFallback = false)
            })
        } else {
            Toast.makeText(this, "Đang tải video quảng cáo AdMob, vui lòng bấm lại sau 2 giây...", Toast.LENGTH_SHORT).show()
            loadNativeRewardedAd(useFallback = true)
        }
    }

    private fun openWithdrawDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 32, 48, 16)
        }

        val methods = arrayOf("Ví MoMo", "Ví ZaloPay", "Tài khoản Ngân hàng (Vietcombank, MB, Techcombank...)")
        val spinnerMethod = Spinner(this).apply {
            adapter = ArrayAdapter(this@NativeGameActivity, android.R.layout.simple_spinner_dropdown_item, methods)
        }

        val edtPoints = EditText(this).apply {
            hint = "Số điểm muốn rút ( tối thiểu 1000 điểm = 100đ )"
            setText("1000")
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        val edtAccount = EditText(this).apply {
            hint = "Số điện thoại MoMo/ZaloPay hoặc Số TK Ngân hàng"
        }

        val edtName = EditText(this).apply {
            hint = "Họ tên chủ tài khoản (VD: NGUYEN VAN A)"
        }

        layout.addView(TextView(this).apply { text = "Chọn kênh nhận tiền:" })
        layout.addView(spinnerMethod)
        layout.addView(edtPoints)
        layout.addView(edtAccount)
        layout.addView(edtName)

        AlertDialog.Builder(this)
            .setTitle("Rút Thưởng (1.000 điểm = 100 VNĐ)")
            .setView(layout)
            .setPositiveButton("Xác nhận rút") { _, _ ->
                val reqPoints = edtPoints.text.toString().toIntOrNull() ?: 0
                val acc = edtAccount.text.toString().trim()
                val holder = edtName.text.toString().trim()
                val channel = spinnerMethod.selectedItem.toString()

                if (reqPoints < 1000) {
                    Toast.makeText(this, "Tối thiểu cần 1.000 điểm (= 100 VNĐ)!", Toast.LENGTH_LONG).show()
                } else if (reqPoints > points) {
                    Toast.makeText(this, "Số dư điểm không đủ!", Toast.LENGTH_LONG).show()
                } else if (acc.isEmpty() || holder.isEmpty()) {
                    Toast.makeText(this, "Vui lòng nhập đủ STK/SĐT và tên chủ TK!", Toast.LENGTH_LONG).show()
                } else {
                    addPoints(-reqPoints)
                    val vndAmount = reqPoints / 10
                    Toast.makeText(
                        this,
                        "✅ Đã tạo lệnh rút $vndAmount VNĐ về $channel ($acc - $holder)!",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    class TreasureCanvasView(
        context: Context,
        private val onEarnPoints: (Int) -> Unit
    ) : View(context) {

        private data class DropItem(var x: Float, var y: Float, val speed: Float, val pts: Int, val isBomb: Boolean)

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val items = mutableListOf<DropItem>()
        private var paddleX = 300f
        private val paddleWidth = 220f
        private val paddleHeight = 44f
        private var tick = 0
        private val shipRect = RectF()

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat().coerceAtLeast(300f)
            val h = height.toFloat().coerceAtLeast(400f)

            canvas.drawColor(Color.parseColor("#090D16"))

            tick++
            if (tick % 35 == 0) {
                val isBomb = Random.nextFloat() < 0.18f
                val isDiamond = Random.nextFloat() < 0.3f
                val pts = if (isBomb) -50 else if (isDiamond) 50 else 20
                items.add(
                    DropItem(
                        x = Random.nextFloat() * (w - 100f) + 50f,
                        y = -30f,
                        speed = Random.nextFloat() * 6f + 7f,
                        pts = pts,
                        isBomb = isBomb
                    )
                )
            }

            val paddleY = h - 110f
            paint.color = Color.parseColor("#F59E0B")
            shipRect.set(paddleX, paddleY, paddleX + paddleWidth, paddleY + paddleHeight)
            canvas.drawRoundRect(shipRect, 24f, 24f, paint)

            val iterator = items.iterator()
            while (iterator.hasNext()) {
                val item = iterator.next()
                item.y += item.speed

                paint.color = when {
                    item.isBomb -> Color.parseColor("#F43F5E")
                    item.pts >= 50 -> Color.parseColor("#38BDF8")
                    else -> Color.parseColor("#FACC15")
                }
                canvas.drawCircle(item.x, item.y, 28f, paint)

                if (item.y + 28f >= paddleY && item.y - 28f <= paddleY + paddleHeight &&
                    item.x >= paddleX && item.x <= paddleX + paddleWidth
                ) {
                    onEarnPoints(item.pts)
                    iterator.remove()
                } else if (item.y > h + 50f) {
                    iterator.remove()
                }
            }

            paint.color = Color.WHITE
            paint.textSize = 32f
            canvas.drawText("Chạm & kéo ngang để hứng Vàng (+20đ), Kim Cương (+50đ)", 32f, 56f, paint)

            postInvalidateOnAnimation()
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_MOVE || event.action == MotionEvent.ACTION_DOWN) {
                paddleX = (event.x - paddleWidth / 2f).coerceIn(16f, (width - paddleWidth - 16f).coerceAtLeast(20f))
                return true
            }
            return super.onTouchEvent(event)
        }
    }
}
